export default function Result({ questions, answers }) {
  const correctCount = questions.filter((q, i) => q.correct.includes(answers[i])).length;

  return (
    <div style={{ padding: 20 }}>
      <h2>Результат</h2>
      <p>Правильних відповідей: {correctCount} з {questions.length}</p>
    </div>
  );
}