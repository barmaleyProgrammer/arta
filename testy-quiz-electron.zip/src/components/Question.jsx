export default function Question({ data, onAnswer, step, total }) {
  return (
    <div style={{ padding: 20 }}>
      <h2>Питання {step + 1} з {total}</h2>
      <p>{data.question}</p>
      {data.image && <img src={data.image} alt="зображення" width="400" />}
      <ul>
        {data.options.map((option, index) => (
          <li key={index}>
            <button onClick={() => onAnswer(index)}>{option}</button>
          </li>
        ))}
      </ul>
    </div>
  );
}