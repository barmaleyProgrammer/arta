import { useState } from 'react';
import questions from './data/questions.json';
import Question from './components/Question';
import Result from './components/Result';

export default function App() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState([]);

  const handleAnswer = (answerIndex) => {
    setAnswers([...answers, answerIndex]);
    setStep(step + 1);
  };

  if (step >= questions.length) {
    return <Result questions={questions} answers={answers} />;
  }

  return (
    <div>
      <Question
        data={questions[step]}
        onAnswer={handleAnswer}
        step={step}
        total={questions.length}
      />
    </div>
  );
}